﻿namespace Database_Project__store_
{
    partial class BranchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.branchSearch_textBox = new System.Windows.Forms.TextBox();
            this.branchSearch_Btn = new System.Windows.Forms.Button();
            this.branchEdit_Btn = new System.Windows.Forms.Button();
            this.branchDelete_Btn = new System.Windows.Forms.Button();
            this.branchInsert_Btn = new System.Windows.Forms.Button();
            this.branchCountry_textBox = new System.Windows.Forms.TextBox();
            this.branchID_textBox = new System.Windows.Forms.TextBox();
            this.branchCity_textBox = new System.Windows.Forms.TextBox();
            this.branchStoreID_textBox = new System.Windows.Forms.TextBox();
            this.branchAvenue_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.searchStoreBranch_Btn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(583, 314);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // branchSearch_textBox
            // 
            this.branchSearch_textBox.Location = new System.Drawing.Point(744, 295);
            this.branchSearch_textBox.Name = "branchSearch_textBox";
            this.branchSearch_textBox.Size = new System.Drawing.Size(139, 22);
            this.branchSearch_textBox.TabIndex = 16;
            this.branchSearch_textBox.TextChanged += new System.EventHandler(this.branchSearch_textBox_TextChanged);
            // 
            // branchSearch_Btn
            // 
            this.branchSearch_Btn.Location = new System.Drawing.Point(601, 287);
            this.branchSearch_Btn.Name = "branchSearch_Btn";
            this.branchSearch_Btn.Size = new System.Drawing.Size(137, 39);
            this.branchSearch_Btn.TabIndex = 15;
            this.branchSearch_Btn.Text = "Search";
            this.branchSearch_Btn.UseVisualStyleBackColor = true;
            this.branchSearch_Btn.Click += new System.EventHandler(this.branchSearch_Btn_Click);
            // 
            // branchEdit_Btn
            // 
            this.branchEdit_Btn.Location = new System.Drawing.Point(601, 242);
            this.branchEdit_Btn.Name = "branchEdit_Btn";
            this.branchEdit_Btn.Size = new System.Drawing.Size(282, 39);
            this.branchEdit_Btn.TabIndex = 14;
            this.branchEdit_Btn.Text = "Edit";
            this.branchEdit_Btn.UseVisualStyleBackColor = true;
            this.branchEdit_Btn.Click += new System.EventHandler(this.branchEdit_Btn_Click);
            // 
            // branchDelete_Btn
            // 
            this.branchDelete_Btn.Location = new System.Drawing.Point(601, 197);
            this.branchDelete_Btn.Name = "branchDelete_Btn";
            this.branchDelete_Btn.Size = new System.Drawing.Size(282, 39);
            this.branchDelete_Btn.TabIndex = 13;
            this.branchDelete_Btn.Text = "Delete";
            this.branchDelete_Btn.UseVisualStyleBackColor = true;
            this.branchDelete_Btn.Click += new System.EventHandler(this.branchDelete_Btn_Click);
            // 
            // branchInsert_Btn
            // 
            this.branchInsert_Btn.Location = new System.Drawing.Point(601, 152);
            this.branchInsert_Btn.Name = "branchInsert_Btn";
            this.branchInsert_Btn.Size = new System.Drawing.Size(282, 39);
            this.branchInsert_Btn.TabIndex = 12;
            this.branchInsert_Btn.Text = "Insert";
            this.branchInsert_Btn.UseVisualStyleBackColor = true;
            this.branchInsert_Btn.Click += new System.EventHandler(this.branchInsert_Btn_Click);
            // 
            // branchCountry_textBox
            // 
            this.branchCountry_textBox.Location = new System.Drawing.Point(601, 40);
            this.branchCountry_textBox.Name = "branchCountry_textBox";
            this.branchCountry_textBox.Size = new System.Drawing.Size(282, 22);
            this.branchCountry_textBox.TabIndex = 18;
            // 
            // branchID_textBox
            // 
            this.branchID_textBox.Location = new System.Drawing.Point(601, 12);
            this.branchID_textBox.Name = "branchID_textBox";
            this.branchID_textBox.Size = new System.Drawing.Size(282, 22);
            this.branchID_textBox.TabIndex = 19;
            // 
            // branchCity_textBox
            // 
            this.branchCity_textBox.Location = new System.Drawing.Point(601, 68);
            this.branchCity_textBox.Name = "branchCity_textBox";
            this.branchCity_textBox.Size = new System.Drawing.Size(282, 22);
            this.branchCity_textBox.TabIndex = 20;
            // 
            // branchStoreID_textBox
            // 
            this.branchStoreID_textBox.Location = new System.Drawing.Point(601, 124);
            this.branchStoreID_textBox.Name = "branchStoreID_textBox";
            this.branchStoreID_textBox.Size = new System.Drawing.Size(282, 22);
            this.branchStoreID_textBox.TabIndex = 21;
            // 
            // branchAvenue_textBox
            // 
            this.branchAvenue_textBox.Location = new System.Drawing.Point(601, 96);
            this.branchAvenue_textBox.Name = "branchAvenue_textBox";
            this.branchAvenue_textBox.Size = new System.Drawing.Size(282, 22);
            this.branchAvenue_textBox.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(891, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = ":BranchID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(891, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 24;
            this.label2.Text = ":Country";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(891, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 25;
            this.label3.Text = ":City";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(891, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 26;
            this.label4.Text = ":Avenue";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(891, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = ":StoreID";
            // 
            // searchStoreBranch_Btn
            // 
            this.searchStoreBranch_Btn.Location = new System.Drawing.Point(12, 332);
            this.searchStoreBranch_Btn.Name = "searchStoreBranch_Btn";
            this.searchStoreBranch_Btn.Size = new System.Drawing.Size(286, 60);
            this.searchStoreBranch_Btn.TabIndex = 28;
            this.searchStoreBranch_Btn.Text = "Search Store branchs with procedure";
            this.searchStoreBranch_Btn.UseVisualStyleBackColor = true;
            this.searchStoreBranch_Btn.Click += new System.EventHandler(this.searchStoreBranch_Btn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(307, 351);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(188, 22);
            this.textBox1.TabIndex = 29;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(286, 60);
            this.button1.TabIndex = 30;
            this.button1.Text = "Delete branch with storeID and BranchID(view)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(307, 398);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 31;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(307, 436);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(429, 439);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.TabIndex = 33;
            this.label6.Text = "StoreID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(429, 401);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 17);
            this.label7.TabIndex = 34;
            this.label7.Text = "BranchID";
            // 
            // BranchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 475);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.searchStoreBranch_Btn);
            this.Controls.Add(this.branchAvenue_textBox);
            this.Controls.Add(this.branchStoreID_textBox);
            this.Controls.Add(this.branchCity_textBox);
            this.Controls.Add(this.branchID_textBox);
            this.Controls.Add(this.branchCountry_textBox);
            this.Controls.Add(this.branchSearch_textBox);
            this.Controls.Add(this.branchSearch_Btn);
            this.Controls.Add(this.branchEdit_Btn);
            this.Controls.Add(this.branchDelete_Btn);
            this.Controls.Add(this.branchInsert_Btn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BranchForm";
            this.Text = "BranchForm";
            this.Load += new System.EventHandler(this.BranchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox branchSearch_textBox;
        private System.Windows.Forms.Button branchSearch_Btn;
        private System.Windows.Forms.Button branchEdit_Btn;
        private System.Windows.Forms.Button branchDelete_Btn;
        private System.Windows.Forms.Button branchInsert_Btn;
        private System.Windows.Forms.TextBox branchCountry_textBox;
        private System.Windows.Forms.TextBox branchID_textBox;
        private System.Windows.Forms.TextBox branchCity_textBox;
        private System.Windows.Forms.TextBox branchStoreID_textBox;
        private System.Windows.Forms.TextBox branchAvenue_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button searchStoreBranch_Btn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}